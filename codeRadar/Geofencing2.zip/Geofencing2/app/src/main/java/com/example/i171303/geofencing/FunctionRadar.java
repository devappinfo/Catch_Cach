package com.example.i171303.geofencing;

import com.google.android.gms.location.Geofence;

public class FunctionRadar {

    public static final String GEOFENCE_ID_100 = "ID_100";
    public static final String GEOFENCE_ID_200 = "ID_200";
    private static final String GEOFENCE_ID_400 = "ID_400" ;
    private static final String GEOFENCE_ID_500 = "ID_500";


    public void useRadar(float lat, float lng){

        Geofence geofence100 = new Geofence.Builder()
                .setRequestId(GEOFENCE_ID_100)
                .setCircularRegion(lat, lng, 100)
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setNotificationResponsiveness(1000)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT)
                .build();

        Geofence geofence200 = new Geofence.Builder()
                .setRequestId(GEOFENCE_ID_200)
                .setCircularRegion(lat, lng, 200)
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setNotificationResponsiveness(1000)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT)
                .build();

        Geofence geofence400 = new Geofence.Builder()
                .setRequestId(GEOFENCE_ID_400)
                .setCircularRegion(lat, lng, 400)
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setNotificationResponsiveness(1000)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT)
                .build();

        Geofence geofence500 = new Geofence.Builder()
                .setRequestId(GEOFENCE_ID_500)
                .setCircularRegion(lat, lng, 500)
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setNotificationResponsiveness(1000)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT)
                .build();
    }
}
