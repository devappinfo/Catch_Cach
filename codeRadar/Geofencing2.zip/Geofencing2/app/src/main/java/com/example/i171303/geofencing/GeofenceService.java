package com.example.i171303.geofencing;

import android.annotation.SuppressLint;
import android.app.IntentService;
import android.app.NotificationManager;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Vibrator;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingEvent;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static com.example.i171303.geofencing.NotifChannel.CHANNEL_1_ID;

public class GeofenceService extends IntentService {

    public static final String TAG = "GeofenceService";

    public GeofenceService() {
        super(TAG);
    }

    public Vibrator vib;
     TimerTask vib100;
     TimerTask vib200;
     TimerTask vib400;
     Timer timer;

    @Override
    protected void onHandleIntent(Intent intent) {
        GeofencingEvent event = GeofencingEvent.fromIntent(intent);
        if (event.hasError()) {
            // TODO: Handle error
        } else {

            int transition = event.getGeofenceTransition();
            List<Geofence> geofences = event.getTriggeringGeofences();
            Geofence geofence = geofences.get(0);
            String requestId = geofence.getRequestId();
        ;

            if (transition == Geofence.GEOFENCE_TRANSITION_ENTER) {
                Log.d(TAG, "Entering geofence - " + requestId);

                if (requestId == "ID_500"){
                    sendNotification();
                }

                if (requestId == "ID_400"){
                    vib400();
                }

                if (requestId == "ID_200"){
                    vib200();
                }

                if (requestId == "ID_100"){
                    vib100();
                }

            } else if (transition == Geofence.GEOFENCE_TRANSITION_EXIT) {
                Log.d(TAG, "Exciting geofence - " + requestId);

                if (requestId == "ID_400"){
                    vib.cancel();
                }

                if (requestId == "ID_200"){
                    vib400();
                }

                if (requestId == "ID_100"){
                  vib200();
                }
            }
        }
    }

    private void sendNotification() {

        Log.d(TAG, "NotifLancée");

        // Construct a task stack.
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);

        // Add the main Activity to the task stack as the parent.
        stackBuilder.addParentStack(MainActivity.class);

        NotifChannel notifChannel = new NotifChannel();


        // Get a notification builder that's compatible with platform versions >= 4
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_1_ID);

        // Define the notification settings.
        builder.setSmallIcon(R.drawable.chat_icon)
                .setColor(Color.RED)
                .setContentTitle("Catch'Cach")
                .setContentText("Notif IUT")
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        // Dismiss notification once the user touches it.
        builder.setAutoCancel(true);

        // Get an instance of the Notification manager
        NotificationManager mNotificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Issue the notification
        if (mNotificationManager != null) {
            Log.d(TAG, "Lancement notify");
            mNotificationManager.notify(1, builder.build());
        }
    }

    private void vib100(){
        vib100 = new TimerTask() {
            @Override
            public void run() {
                vib.vibrate(10);
            }
        };

        timer.schedule(vib100, 10, 2000);

    }

    private void vib200(){
        vib200 = new TimerTask() {
            @Override
            public void run() {
                vib.vibrate(10);
            }
        };

        timer.schedule(vib200, 10, 1000);
    }

    private void vib400() {
        vib400 = new TimerTask() {
            @Override
            public void run() {
                vib.vibrate(10);
            }
        };

        timer.schedule(vib400, 10, 500);
    }

}
