package com.example.to.myapplication.Objets_Communs;
import android.widget.ImageView;
import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Plume extends Objet {

    public Plume(ImageView imageView) {
        super(NomsObjets.PLUME, Rarete.COMMUN, imageView, 1, 1, NomsObjets.LIVRE);

    }

}
