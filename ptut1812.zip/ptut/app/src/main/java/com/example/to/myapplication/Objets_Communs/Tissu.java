package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Tissu extends Objet {

    public Tissu(ImageView imageView) {
        super(NomsObjets.TISSU, Rarete.COMMUN, imageView, 11, 6, NomsObjets.BALLON_DE_FOOT);
    }
}
