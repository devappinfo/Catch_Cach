package com.example.to.myapplication.Objets_Rares;
import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Missile extends Objet {

    public Missile(ImageView imageView) {
        super(NomsObjets.MISSILE, Rarete.RARE, imageView, 28, 14, NomsObjets.ETOILE_FILANTE);
    }
}
