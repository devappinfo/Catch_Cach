package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Papier extends Objet {

    public Papier(ImageView imageView) {
        super(NomsObjets.PAPIER, Rarete.COMMUN, imageView, 2, 1, NomsObjets.LIVRE);
    }
}
