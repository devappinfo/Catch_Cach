package com.example.to.myapplication;

public enum Rarete {
    MAGIQUE, RARE, INHABITUEL, COMMUN, MYTHIQUE;
}
