package com.example.to.myapplication;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.to.myapplication.Objets_Communs.Baguette;
import com.example.to.myapplication.Objets_Communs.Bol;
import com.example.to.myapplication.Objets_Communs.BouleDeFeu;
import com.example.to.myapplication.Objets_Communs.Bracelet;
import com.example.to.myapplication.Objets_Communs.Camembert;
import com.example.to.myapplication.Objets_Communs.Cuillere;
import com.example.to.myapplication.Objets_Communs.Ficelle;
import com.example.to.myapplication.Objets_Communs.Tissu;
import com.example.to.myapplication.Objets_Mythiques.EtoileFilante;
import com.example.to.myapplication.Objets_Mythiques.LivreDeRecette;

public class InventaireActivity extends AppCompatActivity {

    Utilisateur unUser;
    ImageView uneImage;
    ImageView imageResource;
    ImageView imageResource2;
    ImageView imageResource3;
    LinearLayout linearLayoutCommuns;
    LinearLayout linearLayoutInhabituels;
    LinearLayout linearLayoutRares;
    LinearLayout linearLayoutMythiques;
    Objet temp;
    Objet temp2;
    int entier;
    Button buttonvider;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventaire);
        unUser = new Utilisateur();
        linearLayoutCommuns = (LinearLayout) findViewById(R.id.linearLayoutCommun);
        linearLayoutInhabituels = (LinearLayout) findViewById(R.id.linearLayoutInhabituel);
        linearLayoutRares = (LinearLayout) findViewById(R.id.linearLayoutRare);
        linearLayoutMythiques = (LinearLayout) findViewById(R.id.linearLayoutMythique);
        buttonvider = (Button) findViewById(R.id.buttonVider);
        buttonvider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageResource.setImageResource(R.drawable.imageplus);
                imageResource2.setImageResource(R.drawable.imageplus);
                imageResource3.setImageResource(R.drawable.imageplus);
                entier = 0;
            }
        });
        entier = 0;

        imageResource = (ImageView) findViewById(R.id.imageViewResource);
        imageResource2 = (ImageView) findViewById(R.id.imageViewResource2);
        imageResource3 = (ImageView) findViewById(R.id.imageViewResource3);
        entier = 0;

        ImageView img = new ImageView(this);
        img.setImageResource(R.drawable.bolpetite);
        Objet bol = new Bol(img);

        ImageView img2 = new ImageView(this);
        img2.setImageResource(R.drawable.cuillerepetite);
        Objet cuillere = new Cuillere(img2);

        ImageView img3 = new ImageView(this);
        img3.setImageResource(R.drawable.baguettepetite);
        Objet baguette = new Baguette(img3);

        ImageView img4 = new ImageView(this);
        img4.setImageResource(R.drawable.livrerecettepetite);
        Objet livreRecette = new LivreDeRecette(img4);

        ImageView img5 = new ImageView(this);
        img5.setImageResource(R.drawable.etoilefilantepetite);
        Objet etoileFilante = new EtoileFilante(img5);

        ImageView img6 = new ImageView(this);
        img6.setImageResource(R.drawable.braceletpetite);
        Objet bracelet = new Bracelet(img6);

        ImageView img7 = new ImageView(this);
        img7.setImageResource(R.drawable.ficellepetite);
        Objet ficelle = new Ficelle(img7);

        ImageView img8 = new ImageView(this);
        img8.setImageResource(R.drawable.boulefeupetite);
        Objet boulefeu = new BouleDeFeu(img8);

        ImageView img9 = new ImageView(this);
        img9.setImageResource(R.drawable.camembertpetite);
        Objet camembert = new Camembert(img9);

        ImageView img10 = new ImageView(this);
        img10.setImageResource(R.drawable.tissupetite);
        Objet tissu = new Tissu(img10);



        unUser.getListeObjet().add(cuillere);
        unUser.getListeObjet().add(baguette);
        unUser.getListeObjet().add(livreRecette);
        unUser.getListeObjet().add(etoileFilante);
        unUser.getListeObjet().add(bracelet);
        unUser.getListeObjet().add(bol);
        unUser.getListeObjet().add(ficelle);
        unUser.getListeObjet().add(tissu);
        unUser.getListeObjet().add(camembert);
        unUser.getListeObjet().add(boulefeu);

        afficherObjet();
    }


    public void afficherObjet() {
        for (final Objet o : unUser.getListeObjet()) {
            Log.i("coucou", " " + o.getNom());
            switch (o.getRarete()) {
                case COMMUN:
                    linearLayoutCommuns.addView(o.getImageView());
                    break;
                case INHABITUEL:
                    linearLayoutInhabituels.addView(o.getImageView());
                    break;
                case MAGIQUE:
                    break;
                case RARE:
                    linearLayoutRares.addView(o.getImageView());
                    break;
                case MYTHIQUE:
                    linearLayoutMythiques.addView(o.getImageView());
                    break;
            }

            o.getImageView().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (entier == 0) {
                        verification( o.getNom(), imageResource);
                        temp = (Objet) o;
                        entier = 1;
                    } else if (entier == 1) {
                        verification( o.getNom(), imageResource2);
                        temp2 = (Objet) o;
                        entier = 2;
                        if(temp.getIdFusion() == temp2.getIdFusion() && !(temp.equals(temp2))){
                            verification( o.getObjetSuivant(), imageResource3);
                        }
                    } else {

                    }
                }
            });
        }
    }
    public void verification( NomsObjets nomsObjets, ImageView imageView) {
        switch (nomsObjets) {
            case BOL:
                imageView.setImageResource(R.drawable.bolpetite);
                break;
            case TETE:
                imageView.setImageResource(R.drawable.tetepetite);
                break;
            case BAGUETTE:
                imageView.setImageResource(R.drawable.baguettepetite);
                break;
            case PLUME:
                imageView.setImageResource(R.drawable.plumepetite);
                break;
            case BOULE_DE_FEU:
                imageView.setImageResource(R.drawable.boulefeupetite);
                break;
            case HORLOGE:
                imageView.setImageResource(R.drawable.horlogepetite);
                break;
            case CUILLERE:
                imageView.setImageResource(R.drawable.cuillerepetite);
                break;
            case LIVRE:
                imageView.setImageResource(R.drawable.livrepetite);
                break;
            case ETOILE:
                imageView.setImageResource(R.drawable.etoilepetite);
                break;
            case PAPIER:
                imageView.setImageResource(R.drawable.papierpetite);
                break;
            case MONTRE:
                imageView.setImageResource(R.drawable.montrepetite);
                break;
            case CERVEAU:
                imageView.setImageResource(R.drawable.cerveaupetite);
                break;
            case FICELLE:
                imageView.setImageResource(R.drawable.ficellepetite);
                break;
            case LUMIERE:
                imageView.setImageResource(R.drawable.lumierepetite);
                break;
            case MISSILE:
                imageView.setImageResource(R.drawable.missilepetite);
                break;
            case CAOUTCHOUC:
                imageView.setImageResource(R.drawable.caoutchoucpetite);
                break;
            case CAMEMBERT:
                imageView.setImageResource(R.drawable.camembertpetite);
                break;
            case DICTIONNAIRE:
                imageView.setImageResource(R.drawable.dictionnairepetite);
                break;
            case BALLON_DE_FOOT:
                imageView.setImageResource(R.drawable.ballonfootpetite);
                break;
            case ETOILE_FILANTE:
                imageView.setImageResource(R.drawable.etoilefilantepetite);
                break;
            case COCOTTE_MINUTE:
                imageView.setImageResource(R.drawable.cocotteminutepetite);
                break;
            case BOUTEILLE_ALCOOL:
                imageView.setImageResource(R.drawable.bouteillealcoolpetite);
                break;
            case LIVRE_DES_RECETTES:
                imageView.setImageResource(R.drawable.livrerecettepetite);
                break;
            case DRAPEAU_FRANCAIS:
                imageView.setImageResource(R.drawable.drapeaufrancaispetite);
                break;
            case TISSU:
                imageView.setImageResource(R.drawable.tissupetite);
                break;
            case BRACELET:
                imageView.setImageResource(R.drawable.braceletpetite);
                break;
            case BRANCHE:
                imageView.setImageResource(R.drawable.branchepetite);
                break;
            case CASSEROLE:
                imageView.setImageResource(R.drawable.casserolepetite);
                break;
            case CANNE_A_PECHE:
                imageView.setImageResource(R.drawable.canneapechepetite);
                break;
            case COCKTAIL_MOLOTOV:
                imageView.setImageResource(R.drawable.cocktailmolotovpetite);
                break;
            case LIVRE_D_OR_DES_FUSIONS:
                imageView.setImageResource(R.drawable.livreenorpetite);
                break;

        }
    }
    public void pageFusion(View v) {
        //  startActivity(new Intent(this, Fusion.class));
    }
}