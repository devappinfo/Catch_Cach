package com.example.to.myapplication;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class QRCodeActivity extends AppCompatActivity {


    public TextView idQrCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode);

        idQrCode = (TextView) findViewById(R.id.idTextView);
        int nombreAleatoire = 1 + (int)(Math.random() * ((999 - 1) + 1));
        int nombreAleatoire2 = 1 + (int)(Math.random() * ((999 - 1) + 1));
        idQrCode.setText("A"+nombreAleatoire+"B"+nombreAleatoire2);
        // lecture de code barre

    }




}
