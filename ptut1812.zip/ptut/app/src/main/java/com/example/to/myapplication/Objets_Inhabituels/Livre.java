package com.example.to.myapplication.Objets_Inhabituels;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Livre extends Objet {

    public Livre( ImageView imageView) {
        super(NomsObjets.LIVRE, Rarete.INHABITUEL, imageView, 17, 9, NomsObjets.DICTIONNAIRE);
    }
}
