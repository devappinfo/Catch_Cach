package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;
public class Caoutchouc extends Objet {

    public Caoutchouc(ImageView imageView) {
        super(NomsObjets.CAOUTCHOUC, Rarete.COMMUN, imageView, 12, 6, NomsObjets.BALLON_DE_FOOT);
    }
}
