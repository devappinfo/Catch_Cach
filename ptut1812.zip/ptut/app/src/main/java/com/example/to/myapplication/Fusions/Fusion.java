package com.example.to.myapplication.Fusions;

import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import com.example.to.myapplication.MainActivity;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Objet_Magique.LivreEnOr;
import com.example.to.myapplication.Objets_Inhabituels.BallonDeFoot;
import com.example.to.myapplication.Objets_Inhabituels.CanneAPeche;
import com.example.to.myapplication.Objets_Inhabituels.Casserole;
import com.example.to.myapplication.Objets_Inhabituels.Cerveau;
import com.example.to.myapplication.Objets_Inhabituels.CocktailMolotov;
import com.example.to.myapplication.Objets_Inhabituels.DrapeauFrancais;
import com.example.to.myapplication.Objets_Inhabituels.Livre;
import com.example.to.myapplication.Objets_Inhabituels.Montre;
import com.example.to.myapplication.Objets_Mythiques.EtoileFilante;
import com.example.to.myapplication.Objets_Mythiques.LivreDeRecette;
import com.example.to.myapplication.Objets_Rares.CocotteMinute;
import com.example.to.myapplication.Objets_Rares.Dictionnaire;
import com.example.to.myapplication.Objets_Rares.Etoile;
import com.example.to.myapplication.Objets_Rares.Missile;
import com.example.to.myapplication.R;


public class Fusion extends AppCompatActivity {
    Objet temp;
    ImageView image;
    MainActivity mainActivity;

    public Fusion(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    public Objet fusionner(Objet objet1, Objet objet2) {
        if (objet1.getRarete() == objet2.getRarete() && objet1.getIdFusion() == objet2.getIdFusion()) {
            switch (objet1.getObjetSuivant()) {
                case LIVRE:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.livrepetite);
                    temp = new Livre(image);
                    break;
                case ETOILE:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.etoilepetite);
                    temp = new Etoile(image);
                    break;
                case MONTRE:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.montrepetite);
                    temp = new Montre(image);
                    break;
                case CERVEAU:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.cerveaupetite);
                    temp = new Cerveau(image);
                    break;
                case MISSILE:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.missilepetite);
                    temp = new Missile(image);
                    break;
                case DICTIONNAIRE:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.dictionnairepetite);
                    temp = new Dictionnaire(image);
                    break;
                case BALLON_DE_FOOT:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.ballonfootpetite);
                    temp = new BallonDeFoot(image);
                    break;
                case ETOILE_FILANTE:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.etoilefilantepetite);
                    temp = new EtoileFilante(image);
                    break;
                case COCOTTE_MINUTE:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.cocotteminutepetite);
                    temp = new CocotteMinute(image);
                    break;
                case LIVRE_DES_RECETTES:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.livrerecettepetite);
                    temp = new LivreDeRecette(image);
                    break;
                case DRAPEAU_FRANCAIS:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.drapeaufrancaispetite);
                    temp = new DrapeauFrancais(image);
                    break;
                case CASSEROLE:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.casserolepetite);
                    temp = new Casserole(image);
                    break;
                case CANNE_A_PECHE:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.canneapechepetite);
                    temp = new CanneAPeche(image);
                    break;
                case COCKTAIL_MOLOTOV:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.cocktailmolotovpetite);
                    temp = new CocktailMolotov(image);
                    break;
                case LIVRE_D_OR_DES_FUSIONS:
                    image = new ImageView(mainActivity);
                    image.setImageResource(R.drawable.livreenorpetite);
                    temp = new LivreEnOr(image);
                    break;
            }
        }
        return temp;
    }
}


