package com.example.to.myapplication.Objets_Inhabituels;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;


public class CanneAPeche extends Objet {

    public CanneAPeche(ImageView imageView) {
        super(NomsObjets.CANNE_A_PECHE, Rarete.INHABITUEL, imageView, 23, 12, NomsObjets.MISSILE);
    }
}
