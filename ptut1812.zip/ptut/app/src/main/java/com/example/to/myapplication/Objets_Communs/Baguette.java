package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Baguette extends Objet {

    public Baguette( ImageView imageView) {
        super(NomsObjets.BAGUETTE, Rarete.COMMUN, imageView, 10, 5, NomsObjets.DRAPEAU_FRANCAIS);
    }
}
