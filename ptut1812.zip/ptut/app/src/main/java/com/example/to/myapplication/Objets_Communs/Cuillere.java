package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Cuillere extends Objet {

    public Cuillere( ImageView imageView) {
        super(NomsObjets.CUILLERE, Rarete.COMMUN, imageView, 8, 4, NomsObjets.CASSEROLE);
    }
}
