package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Horloge extends Objet {

    public Horloge( ImageView imageView) {
        super(NomsObjets.HORLOGE, Rarete.COMMUN, imageView, 5, 3, NomsObjets.MONTRE);
    }
}
