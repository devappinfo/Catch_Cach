package com.example.to.myapplication.Objets_Communs;
import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Bol extends Objet {

    public Bol( ImageView imageView) {
        super(NomsObjets.BOL, Rarete.COMMUN, imageView, 7, 4, NomsObjets.CASSEROLE);
    }

}
