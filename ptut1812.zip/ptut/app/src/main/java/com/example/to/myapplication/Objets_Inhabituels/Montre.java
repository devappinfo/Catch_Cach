package com.example.to.myapplication.Objets_Inhabituels;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Montre extends Objet {

    public Montre(ImageView imageView) {
        super(NomsObjets.MONTRE, Rarete.INHABITUEL, imageView, 19, 10, NomsObjets.COCOTTE_MINUTE);
    }
}
