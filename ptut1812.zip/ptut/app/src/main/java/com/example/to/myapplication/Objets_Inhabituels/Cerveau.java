package com.example.to.myapplication.Objets_Inhabituels;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Cerveau extends Objet {

    public Cerveau( ImageView imageView) {
        super(NomsObjets.CERVEAU, Rarete.INHABITUEL, imageView, 18, 9, NomsObjets.DICTIONNAIRE);
    }
}
