package com.example.to.myapplication.Objet_Magique;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;


public class LivreEnOr extends Objet {
    public LivreEnOr( ImageView imageView) {
        super(NomsObjets.LIVRE_D_OR_DES_FUSIONS, Rarete.MAGIQUE, imageView, 31, 0, NomsObjets.BOULE_DE_FEU);
    }
}
