package com.example.to.myapplication.Objets_Inhabituels;
import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;


public class DrapeauFrancais extends Objet {

    public DrapeauFrancais(ImageView imageView) {
        super(NomsObjets.DRAPEAU_FRANCAIS, Rarete.INHABITUEL, imageView, 21, 11, NomsObjets.ETOILE);
    }
}
