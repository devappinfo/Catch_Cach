package com.example.to.myapplication.Objets_Communs;
import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Bracelet extends Objet {

    public Bracelet( ImageView imageView) {
        super(NomsObjets.BRACELET, Rarete.COMMUN, imageView, 6, 3, NomsObjets.MONTRE);
    }
}
