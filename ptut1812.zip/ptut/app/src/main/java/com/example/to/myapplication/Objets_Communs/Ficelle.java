package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Ficelle extends Objet {

    public Ficelle( ImageView imageView) {
        super(NomsObjets.FICELLE, Rarete.COMMUN, imageView, 13, 7, NomsObjets.CANNE_A_PECHE);
    }
}
