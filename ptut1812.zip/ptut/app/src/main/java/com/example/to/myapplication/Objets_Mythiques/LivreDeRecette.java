package com.example.to.myapplication.Objets_Mythiques;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class LivreDeRecette extends Objet {

    public LivreDeRecette(ImageView imageView) {
        super(NomsObjets.LIVRE_DES_RECETTES, Rarete.MYTHIQUE, imageView, 29, 15, NomsObjets.LIVRE_D_OR_DES_FUSIONS);
    }

}
