package com.example.to.myapplication.Objets_Rares;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;
public class CocotteMinute extends Objet {

    public CocotteMinute(ImageView imageView) {
        super(NomsObjets.COCOTTE_MINUTE, Rarete.RARE, imageView, 26, 13, NomsObjets.LIVRE_DES_RECETTES);
    }
}
