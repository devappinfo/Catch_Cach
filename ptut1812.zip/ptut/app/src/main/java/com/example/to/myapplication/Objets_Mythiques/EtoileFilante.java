package com.example.to.myapplication.Objets_Mythiques;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;


public class EtoileFilante extends Objet {

    public EtoileFilante(ImageView imageView) {
        super(NomsObjets.ETOILE_FILANTE, Rarete.MYTHIQUE, imageView, 30, 15, NomsObjets.LIVRE_D_OR_DES_FUSIONS);
    }
}
