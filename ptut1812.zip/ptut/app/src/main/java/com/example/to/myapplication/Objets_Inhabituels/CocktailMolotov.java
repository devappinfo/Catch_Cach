package com.example.to.myapplication.Objets_Inhabituels;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;


public class CocktailMolotov extends Objet {

    public CocktailMolotov(ImageView imageView) {
        super(NomsObjets.COCKTAIL_MOLOTOV, Rarete.INHABITUEL, imageView, 24, 12, NomsObjets.MISSILE);
    }
}
