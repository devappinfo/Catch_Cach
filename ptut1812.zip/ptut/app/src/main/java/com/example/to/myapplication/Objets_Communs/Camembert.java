package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Camembert extends Objet {

    public Camembert( ImageView imageView) {
        super(NomsObjets.CAMEMBERT, Rarete.COMMUN, imageView, 9, 5, NomsObjets.DRAPEAU_FRANCAIS);
    }
}
