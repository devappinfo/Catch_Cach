package com.example.to.myapplication.Objets_Inhabituels;

        import android.widget.ImageView;

        import com.example.to.myapplication.NomsObjets;
        import com.example.to.myapplication.Objet;
        import com.example.to.myapplication.Rarete;


public class BallonDeFoot extends Objet {

    public BallonDeFoot(ImageView imageView) {
        super(NomsObjets.BALLON_DE_FOOT, Rarete.INHABITUEL, imageView, 22, 11, NomsObjets.BALLON_DE_FOOT);
    }
}
