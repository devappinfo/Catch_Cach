package com.example.to.myapplication.Objets_Inhabituels;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;


public class Casserole extends Objet {

    public Casserole( ImageView imageView) {
        super(NomsObjets.CASSEROLE, Rarete.INHABITUEL, imageView, 20, 10, NomsObjets.COCOTTE_MINUTE);
    }
}
