package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Tete extends Objet {

    public Tete(ImageView imageView) {
        super(NomsObjets.TETE, Rarete.COMMUN, imageView, 4, 2, NomsObjets.CERVEAU);
    }
}
