package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class BouteilleAlcool extends Objet {

    public BouteilleAlcool(ImageView imageView) {
        super(NomsObjets.BOUTEILLE_ALCOOL, Rarete.COMMUN, imageView, 16, 8, NomsObjets.COCKTAIL_MOLOTOV);
    }
}
