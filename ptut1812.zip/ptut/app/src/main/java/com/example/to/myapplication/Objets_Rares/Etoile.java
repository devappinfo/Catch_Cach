package com.example.to.myapplication.Objets_Rares;
import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;
public class Etoile extends Objet {

    public Etoile( ImageView imageView) {
        super(NomsObjets.ETOILE, Rarete.RARE, imageView, 27, 14, NomsObjets.ETOILE_FILANTE);
    }
}
