package com.example.to.myapplication;

import android.widget.ImageView;

public class Objet {

    protected NomsObjets nom;
    protected Rarete rarete;
    protected ImageView imageView;
    int idFusion;
    protected int idObjet;
    protected NomsObjets objetSuivant;


    public Objet(NomsObjets nom, Rarete rarete, ImageView imageView,  int idObjet, int idFusion, NomsObjets objetSuivant) {
        this.nom = nom;
        this.rarete = rarete;
        this.idFusion = idFusion;
        this.idObjet = idObjet;
        this.objetSuivant = objetSuivant;
        this.imageView = imageView;
    }

    public NomsObjets getNom() {
        return nom;
    }

    public void setNom(NomsObjets nom) {
        this.nom = nom;
    }

    public Rarete getRarete() {
        return rarete;
    }

    public void setRarete(Rarete rarete) {
        this.rarete = rarete;
    }

    public ImageView getImageView() {
        return imageView;
    }

    public void setImageView(ImageView imageView) {
        this.imageView = imageView;
    }

    public int getIdFusion() {
        return idFusion;
    }

    public void setIdFusion(int idFusion) {
        this.idFusion = idFusion;
    }

    public int getIdObjet() {
        return idObjet;
    }

    public void setIdObjet(int idObjet) {
        this.idObjet = idObjet;
    }

    public NomsObjets getObjetSuivant() {
        return objetSuivant;
    }

    public void setObjetSuivant(NomsObjets idObjetSuivant) {
        this.objetSuivant = objetSuivant;
    }
}
