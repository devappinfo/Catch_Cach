package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;
public class Lumiere extends Objet {

    public Lumiere(ImageView imageView) {
        super(NomsObjets.LUMIERE, Rarete.COMMUN, imageView, 3, 2, NomsObjets.CERVEAU);
    }
}
