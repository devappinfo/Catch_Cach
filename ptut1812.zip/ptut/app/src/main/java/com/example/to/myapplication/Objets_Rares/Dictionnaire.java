package com.example.to.myapplication.Objets_Rares;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;
public class Dictionnaire extends Objet {

    public Dictionnaire( ImageView imageView) {
        super(NomsObjets.DICTIONNAIRE, Rarete.RARE, imageView, 25, 13, NomsObjets.LIVRE_DES_RECETTES);
    }
}
