package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;
public class BouleDeFeu extends Objet {

    public BouleDeFeu( ImageView imageView) {
        super(NomsObjets.BOULE_DE_FEU, Rarete.COMMUN, imageView, 15, 8, NomsObjets.COCKTAIL_MOLOTOV);
    }
}
