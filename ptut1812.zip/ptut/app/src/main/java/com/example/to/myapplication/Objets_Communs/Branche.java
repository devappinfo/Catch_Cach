package com.example.to.myapplication.Objets_Communs;

import android.widget.ImageView;

import com.example.to.myapplication.NomsObjets;
import com.example.to.myapplication.Objet;
import com.example.to.myapplication.Rarete;

public class Branche extends Objet {

    public Branche(ImageView imageView) {
        super(NomsObjets.BRANCHE, Rarete.COMMUN, imageView, 14, 7, NomsObjets.CANNE_A_PECHE);
    }
}
